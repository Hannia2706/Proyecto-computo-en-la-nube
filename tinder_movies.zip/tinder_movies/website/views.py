# Librerías y moulos
from django.shortcuts import render

# Vistas de la aplicación


def inicio(request):
    '''
    Función que muestra la vista de la página de inicio
    '''
    return render(request, 'home.html')


def tinder_movies(request):
    '''
    Función que muestra la vista de el formulario de selección de 
    películas y las películas recomendadas por el algoritmo
    '''
    if request.method == 'POST':
        # En caso de ser el método POST, obtenemos las películas
        # que el usuario ha seleccionado
        selected_movies = request.POST.get('movies')

        # ...

        # Obtenemos las películas recomendadas por el algoritmo
        movie1 = 'Actividad Paranormal'
        movie2 = 'El Conjuro'

        # Mostramos las películas recomendadas
        return render(request, 'recommended_movies.html', {
            'movie1': movie1,
            'movie2': movie2
        })

    else:
        # En caso de ser el método GET, mostramos la página de inicio
        return render(request, 'tinder_movies.html')
