# Librerías y modulos
from django.urls import path
from . import views

# Rutas de las vistas de la aplicación
urlpatterns = [
    path('', views.inicio, name='home'),
    path('tinder_movies/', views.tinder_movies, name='tinder_movies'),
]